+++
# Recent Publications widget.
# This widget displays recent publications from `content/publication/`.

date = "2016-04-20T00:00:00"
draft = false

title = "Recent Publications"
subtitle = ""
widget = "publications"

# Order that this section will appear in.
weight = 20

# Number of publications to list.
count = 10

# Show publication details (such as abstract)? (true/false)
detailed_list = false

+++

